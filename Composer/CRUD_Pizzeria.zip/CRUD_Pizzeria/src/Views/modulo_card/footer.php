<footer class="d-flex flex-wrap justify-content-center align-items-center py-3 my-4 border-top">
    <div class="col-md-4 d-flex align-items-center">
        <span class="mb-3 mb-md-0 text-body-secondary" style="text-align: center;">
            Victor Manuel Corral Ruiz - CRUD Pizzeria - 2ºDAW 2025/2026
        </span>
    </div>
</footer>