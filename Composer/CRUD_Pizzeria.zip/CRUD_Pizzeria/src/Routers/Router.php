<?php
    namespace App\Routes;

    class Router{
        private $routes = [];

        public function __construct(){
            $this ->cargarRutas();
        }

        public function cargarRutas(){
            $this ->routes["/"] = ["controller" => "HomeControllers", "action" => "index"];
            $this ->routes["/listPizzas"] = ["controller" => "HomeControllers", "action" => "listPizzas"];
            $this ->routes["/updatePizza"] = ["controller" => "HomeControllers", "action" => "updatePizza"];
            $this ->routes["/updatePizza2"] = ["controller" => "HomeControllers", "action" => "updatePizza2"];
            $this ->routes["/delPizza"] = ["controller" => "HomeControllers", "action" => "delPizza"];
            $this ->routes["/addPizza"] = ["controller" => "HomeControllers", "action" => "addPizza"];
            $this ->routes["/addPizza2"] = ["controller" => "HomeControllers", "action" => "addPizza2"];
        }

        public function peticion(){
            //$ruta = $_SERVER['REQUEST_URI'];
            // parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH)  -- limpia la url para poder entrar en las rutas
            $ruta = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            $method = $_SERVER['REQUEST_METHOD'];

            if (isset($this->routes[$ruta])){
                $route = $this->routes[$ruta];
                $controllerClass = 'App\\Controllers\\' . $route['controller'];
                $accion = $route["action"];
                
                
                if(!class_exists($controllerClass)) {
                    echo "No existe la clase <br>";
                    echo $controllerClass . "<br>";
                }
                

                if(class_exists($controllerClass) && method_exists($controllerClass, $accion)){
                    $controller = new $controllerClass();

                    if($method == "GET"){
                        $controller ->$accion($_GET);
                    } else {
                        $controller ->$accion($_POST);
                    }
                    
                } else {
                    echo "NO existe el controlador o el metodo <br>";
                }
            } else {
                echo "NO existe la ruta";
            }
        }
    
    }

    $instancia = new Router();
    $instancia->peticion();